﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCatalogue.BLL.DTO
{
    public class LanguageDTO
    {
        public int Id { get; set; }
        public string LanguageName { get; set; }
    }
}
